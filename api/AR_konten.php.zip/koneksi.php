<?php
$server = "localhost";
$username = "topp3988_app-learning";
$password = "app-learning";
$database = "topp3988_ar_pekanbaru";

// Koneksi dan memilih darabase di server
mysql_connect($server,$username,$password) or die("Koneksi gagal");
mysql_select_db($database) or die("Database tidak bisa dibuka");
?>