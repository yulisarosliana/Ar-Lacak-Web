<?php
/* AR_konten.php
     untuk retrieve data  pos polisi dari server ke native
    */
$hostname = "localhost";
$mysqluser = "topp3988_app-learning";
$mysqlpassword = "app-learning";
$conn = mysql_connect($hostname,$mysqluser,$mysqlpassword);
if (!$conn){
	die('Could not connect: ' . mysql_error());
}
if (!mysql_select_db('topp3988_ar_pekanbaru')){
	die('Could not select database: ' . mysql_error());
}

$result = mysql_query('SELECT `id`,`lat`,`lng`,`altitude`,`title`,`streetAddress`,`number`,`deskripsi`,`image` FROM `tb_lokasi_penting` ORDER BY id ASC');
	if (!$result) {
		die('Could not query:' . mysql_error());
	}
	$rows = array();
	while($r = mysql_fetch_assoc($result)) {
		$rows[] = $r;
	}
	mysql_close($conn);
echo '{"results":'.json_encode($rows).'}';
?>
